$(document).ready(function(){

$('form[id="form_val2"]').validate({
rules:{
password: {
required: true,
	maxlength:6
	


},
confirmpassword:{
required: true,
equalTo: "#password"
}
},
messages:{
password:{
required: "Enter the password",
	maxlength: "maximum length should be 6"
	

},
confirmpassword:{
required:"Enter confirm password",
equalTo:"Passwords does not match",
}
},
submitHandler:function(form){
form.submit();
}
});
});
